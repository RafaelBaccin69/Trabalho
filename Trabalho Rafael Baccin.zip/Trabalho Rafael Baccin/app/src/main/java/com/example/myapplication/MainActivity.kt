package com.example.myapplication

import android.R
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat




            class MainActivity : AppCompatActivity() {
                private var etNome: EditText? = null
                private var etEmail: EditText? = null
                private var etIdade: EditText? = null
                private var etDisciplina: EditText? = null
                private var etNota1: EditText? = null
                private var etNota2: EditText? = null
                private var tvResultado: TextView? = null
                private var btnEnviar: Button? = null
                private var btnLimpar: Button? = null

                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    setContentView(R.layout.activity_main)

                    etNome = findViewById<EditText>(R.id.etNome)
                    etEmail = findViewById<EditText>(R.id.etEmail)
                    etIdade = findViewById<EditText>(R.id.etIdade)
                    etDisciplina = findViewById<EditText>(R.id.etDisciplina)
                    etNota1 = findViewById<EditText>(R.id.etNota1)
                    etNota2 = findViewById<EditText>(R.id.etNota2)
                    tvResultado = findViewById<TextView>(R.id.tvResultado)
                    btnEnviar = findViewById<Button>(R.id.btnEnviar)
                    btnLimpar = findViewById<Button>(R.id.btnLimpar)

                    btnEnviar.setOnClickListener(View.OnClickListener { v: View? -> validarEExibirDados() })
                    btnLimpar.setOnClickListener(View.OnClickListener { v: View? -> limparFormulario() })
                }

                private fun validarEExibirDados() {
                    val nome = etNome!!.text.toString()
                    val email = etEmail!!.text.toString()
                    val idadeStr = etIdade!!.text.toString()
                    val disciplina = etDisciplina!!.text.toString()
                    val nota1Str = etNota1!!.text.toString()
                    val nota2Str = etNota2!!.text.toString()

                    if (nome.isEmpty() || email.isEmpty() || idadeStr.isEmpty() || disciplina.isEmpty() || nota1Str.isEmpty() || nota2Str.isEmpty()) {
                        tvResultado!!.text = "Todos os campos são obrigatórios."
                        return
                    }

                    val idade: Int
                    val nota1: Double
                    val nota2: Double
                    try {
                        idade = idadeStr.toInt()
                        nota1 = nota1Str.toDouble()
                        nota2 = nota2Str.toDouble()
                    } catch (e: NumberFormatException) {
                        tvResultado!!.text = "Idade e notas devem ser números válidos."
                        return
                    }

                    if (idade <= 0 || nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
                        tvResultado!!.text = "Idade deve ser positiva e notas entre 0 e 10."
                        return
                    }

                    val media = (nota1 + nota2) / 2
                    val status = if (media >= 6) "Aprovado" else "Reprovado"

                    tvResultado!!.text = String.format(
                        "Nome: %s\nEmail: %s\nIdade: %d\nDisciplina: %s\nNotas 1º e 2º Bimestres: %.2f, %.2f\nMédia: %.2f\nStatus: %s",
                        nome, email, idade, disciplina, nota1, nota2, media, status
                    )
                }

                private fun limparFormulario() {
                    etNome!!.setText("")
                    etEmail!!.setText("")
                    etIdade!!.setText("")
                    etDisciplina!!.setText("")
                    etNota1!!.setText("")
                    etNota2!!.setText("")
                    tvResultado!!.text = ""
                }
            }
        }
    }
}