public class MainActivity extends AppCompatActivity {

    private EditText etNome, etEmail, etIdade, etDisciplina, etNota1, etNota2;
    private TextView tvResultado;
    private Button btnEnviar, btnLimpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNome = findViewById(R.id.etNome);
        etEmail = findViewById(R.id.etEmail);
        etIdade = findViewById(R.id.etIdade);
        etDisciplina = findViewById(R.id.etDisciplina);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        tvResultado = findViewById(R.id.tvResultado);
        btnEnviar = findViewById(R.id.btnEnviar);
        btnLimpar = findViewById(R.id.btnLimpar);

        btnEnviar.setOnClickListener(v -> validarEExibirDados());
        btnLimpar.setOnClickListener(v -> limparFormulario());
    }

    private void validarEExibirDados() {
        String nome = etNome.getText().toString();
        String email = etEmail.getText().toString();
        String idadeStr = etIdade.getText().toString();
        String disciplina = etDisciplina.getText().toString();
        String nota1Str = etNota1.getText().toString();
        String nota2Str = etNota2.getText().toString();

        if (nome.isEmpty() || email.isEmpty() || idadeStr.isEmpty() || disciplina.isEmpty() || nota1Str.isEmpty() || nota2Str.isEmpty()) {
            tvResultado.setText("Todos os campos são obrigatórios.");
            return;
        }

        int idade;
        double nota1, nota2;
        try {
            idade = Integer.parseInt(idadeStr);
            nota1 = Double.parseDouble(nota1Str);
            nota2 = Double.parseDouble(nota2Str);
        } catch (NumberFormatException e) {
            tvResultado.setText("Idade e notas devem ser números válidos.");
            return;
        }

        if (idade <= 0 || nota1 < 0 || nota1 > 10 || nota2 < 0 || nota2 > 10) {
            tvResultado.setText("Idade deve ser positiva e notas entre 0 e 10.");
            return;
        }

        double media = (nota1 + nota2) / 2;
        String status = media >= 6 ? "Aprovado" : "Reprovado";

        tvResultado.setText(String.format("Nome: %s\nEmail: %s\nIdade: %d\nDisciplina: %s\nNotas 1º e 2º Bimestres: %.2f, %.2f\nMédia: %.2f\nStatus: %s",
                nome, email, idade, disciplina, nota1, nota2, media, status));
    }

    private void limparFormulario() {
        etNome.setText("");
        etEmail.setText("");
        etIdade.setText("");
        etDisciplina.setText("");
        etNota1.setText("");
        etNota2.setText("");
        tvResultado.setText("");
    }
}